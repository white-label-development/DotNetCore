Useful Links for Module 6 - Securing Microservices
===============================================================

For learning more about OAuth 2 and OpenID Connect I recommend these courses:
https://www.pluralsight.com/courses/oauth-2-getting-started
https://www.pluralsight.com/courses/aspdotnet-authentication-big-picture
https://www.pluralsight.com/courses/securing-aspdotnet-core2-oauth2-openid-connect

The identity server used by eShopOnContainers is found here:
https://github.com/IdentityServer/IdentityServer4
https://identityserver.io/