Useful Links for Module 2 - Introducing Microservices
=====================================================

eShopOnContainers sample application:
https://github.com/dotnet-architecture/eShopOnContainers

Getting started instructions
Windows: https://github.com/dotnet-architecture/eShopOnContainers/wiki/Windows-setup
Mac: https://github.com/dotnet-architecture/eShopOnContainers/wiki/Mac-setup

Free eBooks associated with the sample application:
https://aka.ms/microservicesebook
https://aka.ms/dockerlifecycleebook