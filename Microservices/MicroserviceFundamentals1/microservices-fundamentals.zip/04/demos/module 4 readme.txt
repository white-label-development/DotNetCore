Useful Links for Module 4 - Building Microservices
=====================================================


These are my courses about Azure Functions which can be used to build serverless microservice applications on Azure:
https://app.pluralsight.com/library/courses/azure-serverless-applications
https://app.pluralsight.com/library/courses/azure-functions-fundamentals
https://app.pluralsight.com/library/courses/microsoft-azure-serverless-functions-create


The latest source code for the demo eShopOnContainers application can be found here:
https://github.com/dotnet-architecture/eShopOnContainers

The exact version of the demo app source code I showed in this module can be found here:
https://github.com/dotnet-architecture/eShopOnContainers/tree/9dae52f80bddce4ead69717c8546c82e1d8eecac

