Useful Links for Module 3 - Architecting Microservices
=====================================================

Recommended resources for learning more about DDD:

Pluralsight Domain-Driven Design Learning Path:
https://app.pluralsight.com/paths/skills/domain-driven-design

Books: 
Domain-Driven Design by Eric J Evans
Implementing Domain_Driven Design by Vaughn Vernon
