﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TennisBookings.Merchandise.Api.Models.Output
{
    public class StockTotalOutputModel
    {
        public int StockItemTotal { get; set; }
    }
}
