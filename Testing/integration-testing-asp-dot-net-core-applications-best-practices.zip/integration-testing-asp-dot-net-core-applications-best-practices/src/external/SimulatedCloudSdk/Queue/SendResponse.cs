﻿namespace SimulatedCloudSdk.Queue
{
    public class SendResponse
    {
        public int StatusCode { get; set; }
        public bool IsSuccess { get; set; }
    }
}
