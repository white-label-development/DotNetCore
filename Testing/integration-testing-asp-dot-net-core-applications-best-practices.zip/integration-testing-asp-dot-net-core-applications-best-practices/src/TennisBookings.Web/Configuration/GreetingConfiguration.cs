﻿namespace TennisBookings.Web.Configuration
{
    public class GreetingConfiguration
    {
        public string GreetingColour { get; set; }
    }
}
