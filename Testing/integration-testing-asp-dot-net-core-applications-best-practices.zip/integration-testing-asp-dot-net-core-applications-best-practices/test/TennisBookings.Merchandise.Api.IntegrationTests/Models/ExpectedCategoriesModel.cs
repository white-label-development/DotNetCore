﻿using System.Linq;
using System.Threading.Tasks;

namespace TennisBookings.Merchandise.Api.IntegrationTests.Models
{
    public class ExpectedCategoriesModel
    {
        public string[] AllowedCategories { get; set; }
    }
}
