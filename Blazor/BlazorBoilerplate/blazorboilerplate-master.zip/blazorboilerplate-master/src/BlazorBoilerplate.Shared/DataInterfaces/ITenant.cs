﻿namespace BlazorBoilerplate.Shared.DataInterfaces
{
    public interface ITenant
    {
    }
}
