﻿namespace BlazorBoilerplate.Shared.DataInterfaces
{
    public interface ISoftDelete
    {
    }
}
