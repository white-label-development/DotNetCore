﻿namespace BlazorBoilerplate.Shared.DataInterfaces
{
    public interface IAuditable
    {
    }
}
