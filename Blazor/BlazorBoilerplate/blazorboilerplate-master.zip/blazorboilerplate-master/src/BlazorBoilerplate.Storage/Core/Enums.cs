﻿namespace BlazorBoilerplate.Storage.Core
{
    public enum Gender
    {
        None,
        Female,
        Male
    }
}
