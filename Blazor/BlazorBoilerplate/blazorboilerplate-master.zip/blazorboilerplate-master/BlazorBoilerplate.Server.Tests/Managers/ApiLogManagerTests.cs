﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace BlazorBoilerplate.Server.Tests.Managers
{
    [TestFixture]
    class ApiLogManagerTests
    {
        // I will leave this for testing, for now.

        [Test]
        public void SetupWorked()
        {
            Assert.Pass();
        }
    }
}
