﻿namespace BlazorBoilerplate.Server.Tests.Managers
{
    internal class TodoManager
    {
    }
}